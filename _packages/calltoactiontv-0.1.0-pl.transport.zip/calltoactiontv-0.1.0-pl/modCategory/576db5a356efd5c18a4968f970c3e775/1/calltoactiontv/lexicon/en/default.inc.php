<?php
/**
 * Default English Lexicon Entries for CallToActionTv
 *
 * @package calltoactiontv
 * @subpackage lexicon
 */

$_lang['calltoactiontv'] = 'CallToAction TV';

$_lang['calltoactiontv.link'] = 'Link';
$_lang['calltoactiontv.text'] = 'Text';
$_lang['calltoactiontv.label'] = 'Label';
$_lang['calltoactiontv.target'] = 'Target';
$_lang['calltoactiontv.btnclass'] = 'Class';
